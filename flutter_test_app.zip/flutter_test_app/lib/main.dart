import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Report Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ReportPage(),
    );
  }
}

class ReportPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reports'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Date Selector
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Select date'),
                Icon(Icons.arrow_downward),
              ],
            ),
            SizedBox(height: 16),

            // Data Fields
            ReportField(label: 'Lot no :', value: 'Value'),
            ReportField(label: 'Agg Weight :', value: 'Value'),
            ReportField(label: 'Grade 1 :', value: 'Value'),
            ReportField(label: 'Grade 2 :', value: 'Value'),
            ReportField(label: 'Grade 3 :', value: 'Value'),
            ReportField(label: 'Grade 4 :', value: 'Value'),
            ReportField(label: 'Wastage :', value: 'Value'),

            SizedBox(height: 16),

            // Placeholder for graphical representation
            Container(
              height: 200,
              width: double.infinity,
              color: Colors.grey[300],
              child: Center(child: Text('Graphical representation goes here')),
            ),

            SizedBox(height: 16),

            // Download PDF Button
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // Add PDF download logic here
                },
                child: Text('Download PDF'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green, // Updated
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ReportField extends StatelessWidget {
  final String label;
  final String value;

  ReportField({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 16)),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
